/** Automatically generated file. DO NOT MODIFY */
package com.haoge.luanru;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}