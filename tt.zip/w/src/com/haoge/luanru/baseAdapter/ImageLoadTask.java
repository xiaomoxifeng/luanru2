package com.haoge.luanru.baseAdapter;

import android.graphics.Bitmap;

public class ImageLoadTask {
	public String path;
	public Bitmap bitmap;
}
