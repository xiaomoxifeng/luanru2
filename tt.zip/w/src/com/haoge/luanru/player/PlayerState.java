package com.haoge.luanru.player;

public class PlayerState {
	public final static int UNSTART = 0;
	public final static int PLAYING = 1;
	public final static int PAUSE = 3;
	public final static int STOP = 4;
	
}
