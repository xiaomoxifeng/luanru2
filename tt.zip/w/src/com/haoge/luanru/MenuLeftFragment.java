package com.haoge.luanru;

import java.util.Arrays;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.haoge.luanru.music.activity.MusicMainActivity;

public class MenuLeftFragment extends Fragment {
	private View mView;
	private ListView mCategories;
	private List<String> mDatas = Arrays.asList("乱首页","乱音乐", "乱视频", "乱事儿",
			"乱聊儿", "乱画儿", "乱设置" );
	private ListAdapter mAdapter;

	// private SimpleAdapter sAdapter;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		if (mView == null) {
			mView = inflater.inflate(R.layout.left_menu, container, false);
			mCategories = (ListView) mView
					.findViewById(R.id.id_listview_categories);
			mAdapter = new ArrayAdapter<String>(getActivity(),
					android.R.layout.simple_list_item_1, mDatas);
			mCategories.setAdapter(mAdapter);
			mCategories.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					// TODO Auto-generated method stub
					String name = mDatas.get(position);
					Toast.makeText(getActivity(), name, Toast.LENGTH_SHORT)
							.show();
					if (name.equals("乱音乐")) {
						Intent intent = new Intent(getActivity(),
								MusicMainActivity.class);
						startActivity(intent);
					} else if (name.equals("乱首页")) {
						Intent intent = new Intent(getActivity(),
								MainActivity.class);
						startActivity(intent);
					}
				}

			});
		}

		return mView;

	}

}
