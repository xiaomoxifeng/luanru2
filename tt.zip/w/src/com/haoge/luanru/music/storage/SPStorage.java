package com.haoge.luanru.music.storage;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
//设置属性功能尚未实现
public class SPStorage {
	private SharedPreferences mSp;
	private Editor mEditor;
	public void savePath(String path) {
		
	}
}
