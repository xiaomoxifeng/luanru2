package com.haoge.luanru.utils;

import android.os.Environment;

public class GlobalConsts {
	public static final String BASEURL="";
	public static final String EXTERNALSTORAGE = Environment
			.getExternalStoragePublicDirectory("乱入的世界").toString();
	
	public static final String BMOB_APPID="f299718183599f03b69d289d4688bd38";
	//图灵机器人
		public static final String ROBOT_URL="http://www.tuling123.com/openapi/api";
		public static final String ROBOT_API_KEY="2b514c7ec1489cf6eb000d62920901da";
		//微信语音
		public static final String WEIXIN_API_KEY = "39d77d64c1be90c910023597beaf7a4af5fbf7dbe088a748";
}
